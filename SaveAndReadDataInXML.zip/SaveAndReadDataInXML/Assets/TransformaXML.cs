﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;
using UnityEngine.UI;
using System.Reflection;

public class TransformaXML : MonoBehaviour {

	private XmlDocument xmlDoc;
    public Text infoTxt;
    private bool nameExists, scoreExists;
	//Load XML
	public void loadXMLFromAssets(){
		
		xmlDoc = new XmlDocument();
		TextAsset textXml = (TextAsset)Resources.Load("jugadores", typeof(TextAsset));
		xmlDoc.LoadXml(textXml.text);	
	}

    //This function reads the XML data and shows it in console.
	public void readXml(){
        //Clean console
        ClearLog();

        if (xmlDoc == null)
        {
            loadXMLFromAssets();
        }
                
        List<Player>listPlayers = new List<Player> ();

		foreach(XmlElement node in xmlDoc.SelectNodes("players/player"))
		{
			Player tempPlayer = new Player();
			tempPlayer.id = int.Parse(node.GetAttribute("id"));
			tempPlayer.name = node.SelectSingleNode("nombre").InnerText;
			tempPlayer.score = int.Parse(node.SelectSingleNode("puntos").InnerText);
			listPlayers.Add(tempPlayer);
			Debug.Log ("ID: "+tempPlayer.id);
			Debug.Log ("NOMBRE: "+tempPlayer.name);
			Debug.Log ("PUNTOS: "+tempPlayer.score);
		}
	}

    //This function writes a new entry on XML file.
	public void saveXML(){

        if (xmlDoc == null)
        {
            loadXMLFromAssets();
        }
        //Crea los elementos y los atributos
        XmlNode parentNode = xmlDoc.SelectSingleNode ("players");
		XmlNode playerNode = xmlDoc.CreateElement ("player");
        XmlAttribute idAttr = xmlDoc.CreateAttribute("id");
        XmlNode nameNode = xmlDoc.CreateElement("nombre");
        XmlNode scoreNode = xmlDoc.CreateElement("puntos");

        //Asigna los valores
        idAttr.Value= Random.Range(10,10000).ToString();
        
        if(GameObject.Find("Nombre").GetComponent<InputField>().text != "")
        {
            nameNode.InnerText = GameObject.Find("Nombre").GetComponent<InputField>().text;
            nameExists = true;
        }
        else
        {         
            infoTxt.color = Color.red;
            infoTxt.text = "No has introducido ningún nombre";
            Invoke("eraseInfoText", 2);
        }
        if(GameObject.Find("Puntos").GetComponent<InputField>().text != "")
        {
            scoreNode.InnerText = GameObject.Find("Puntos").GetComponent<InputField>().text;
            scoreExists = true;
        }
        else
        {
            infoTxt.color = Color.red;
            infoTxt.text = "No has introducido ninguna puntuacion";
            Invoke("eraseInfoText", 2);
        }        
        
        if(nameExists && scoreExists)
        {
            parentNode.AppendChild(playerNode);
            playerNode.Attributes.Append(idAttr);
            playerNode.AppendChild(nameNode);
            playerNode.AppendChild(scoreNode);
            xmlDoc.Save(Application.dataPath + "/Resources/jugadores.xml");

            infoTxt.text = "Los datos se han guardado correctamente.";
            infoTxt.color = Color.green;
            Invoke("eraseInfoText", 2);
        }
        
        

    }

    //This method clears unity editor console.
    public static void ClearLog()
    {
        var assembly = Assembly.GetAssembly(typeof(UnityEditor.ActiveEditorTracker));
        var type = assembly.GetType("UnityEditorInternal.LogEntries");
        var method = type.GetMethod("Clear");
        method.Invoke(new object(), null);
    }

    private void eraseInfoText()
    {
        infoTxt.text = "";
    }
}
