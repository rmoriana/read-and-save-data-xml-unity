﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player {

	public int id { get; set;}
	public string name{ get; set;}
	public int score{ get; set;}
}
