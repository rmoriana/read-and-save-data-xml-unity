﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonController : MonoBehaviour {

	public void guardaDatos()
    {
        GameObject.FindGameObjectWithTag("MainCamera").GetComponent<TransformaXML>().saveXML();
    }

    public void muestraDatos()
    {
        GameObject.FindGameObjectWithTag("MainCamera").GetComponent<TransformaXML>().readXml();
    }
}
